BENCHMARK CONFIGURATION FILES, Desmond/GPU Performance
DESRES/TR--2021-01

Configuration files for benchmarks with a time step of 2.5fs are in the
./2.5fs directory, while configuration files for benchmarks with a 4.0-fs
time step are in the ./4.0fs directory.

.
├── 2.5fs
│   ├── 10stmv.ark
│   ├── apoa1.ark
│   ├── dhfr.ark
│   ├── f1atpase.ark
│   ├── ribosome.ark
│   └── stmv.ark
└── 4.0fs
    ├── 10stmv.ark
    ├── apoa1.ark
    ├── dhfr.ark
    ├── f1atpase.ark
    ├── ribosome.ark
    └── stmv.ark

These files are provided under the Creative Commons Attribution 4.0 International Public License (http://creativecommons.org/licenses/by/4.0/).
